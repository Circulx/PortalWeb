'use client'

import React from 'react'
import { usePathname } from 'next/navigation'

export function LayoutWrapper({
  children,
}: {
  children: React.ReactNode
}) {
  const pathname = usePathname()

  // Hide header and footer for admin and seller portal login pages
  const isAdminOrSellerPortal = pathname === '/admin' || pathname === '/seller'

  // Filter children to conditionally render header, main, and footer
  const childrenArray = React.Children.toArray(children)
  
  return (
    <>
      {childrenArray.map((child, index) => {
        // Check if this is the Header component (first child after LayoutWrapper)
        const isHeader = index === 0
        const isFooter = index === childrenArray.length - 1
        
        if (isHeader && isAdminOrSellerPortal) {
          return null
        }
        
        if (isFooter && isAdminOrSellerPortal) {
          return null
        }
        
        // For main content, adjust classes if on portal login pages
        if (index === 1 && isAdminOrSellerPortal) {
          return React.cloneElement(child as React.ReactElement, {
            key: index,
            className: 'w-full max-w-full overflow-x-hidden',
          })
        }
        
        return <React.Fragment key={index}>{child}</React.Fragment>
      })}
    </>
  )
}
