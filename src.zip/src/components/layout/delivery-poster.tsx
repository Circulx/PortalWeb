"use client"

import Image from "next/image"

export default function DeliveryPoster() {
  return (
    <section className="">
      {/* 
        Image Size Recommendations:
        - Your image appears to be approximately 3:1 aspect ratio
        - For best results, create image at 1200x400px or 1500x500px
        - For high-DPI displays: 2400x800px or 3000x1000px
        - File format: PNG for transparency or JPG for smaller file size
        - Keep file size under 200KB for performance
        - Design should work well when stretched to full width
      */}

      {/* Full width container that covers complete section 
      <div className="relative w-full h-40 sm:h-48 md:h-56 lg:h-64 xl:h-72">
        <Image
          src="/poster1.png"
          alt="On Time Delivery - Professional delivery service with fast delivery, professional service, and guaranteed quality"
          fill
          className="object-cover w-full h-full"
          sizes="100vw"
          priority
        />
      </div> */}

      {/* 
        Alternative approach - Full width with natural height:
        This stretches the image to full width and adjusts height accordingly
        Uncomment below if you prefer this approach:
      */}
      {
      <div className="relative w-full">
        <Image
          src="/poster1.png"
          alt="On Time Delivery - Professional delivery service"
          width={1200}
          height={400}
          className="w-full h-auto object-cover"
          sizes="100vw"
          priority
        />
      </div>
      }

      {/* 
        Edge-to-edge approach (breaks out of container margins):
        Use this if you want the image to extend beyond page margins
        Uncomment below if needed:
      */}
      {/*
      <div className="relative w-screen h-40 sm:h-48 md:h-56 lg:h-64 xl:h-72 -mx-4 sm:-mx-6 lg:-mx-8">
        <Image
          src="/images/poster.png"
          alt="On Time Delivery - Professional delivery service"
          fill
          className="object-cover w-full h-full"
          sizes="100vw"
          priority
        />
      </div>
      */}
    </section>
  )
}
