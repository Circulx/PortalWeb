export function Header() {
  return <div className="border-b"></div>
}

