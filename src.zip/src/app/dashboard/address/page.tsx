import AddressPage from "@/components/dashboard/AddressPage"

export default function DashboardAddressPage() {
  return <AddressPage />
}
