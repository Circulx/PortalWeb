import CartPage from "@/components/dashboard/cart-summary"

export default function DashboardCartPage() {
  return <CartPage />
}
