import OrdersPage from "@/components/dashboard/OrdersPage"

export default function DashboardOrdersPage() {
  return <OrdersPage />
}

