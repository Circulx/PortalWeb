import AccountSettings from "@/components/dashboard/AccountSettings"

export default function DashboardPage() {
  return <AccountSettings />
}
