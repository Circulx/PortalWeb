import Link from "next/link"

async function getCareers() {
  const res = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL || ""}/api/careers`, { cache: "no-store" })
  const json = await res.json()
  return json.success ? json.data : []
}

export default async function CareersPage() {
  const careers = await getCareers()

  return (
    <main className="min-h-screen bg-white">
      <section className="bg-black text-white">
        <div className="container mx-auto px-4 py-12 md:py-16">
          <h1 className="text-3xl md:text-4xl font-bold text-balance">Join Our Team</h1>
          <p className="mt-3 text-gray-300 max-w-2xl">
            Build the future of B2B commerce. Explore open roles and internships across product, engineering, design,
            and operations.
          </p>
        </div>
      </section>

      <section className="container mx-auto px-4 py-10 md:py-14">
        {careers.length === 0 ? (
          <p className="text-gray-600">No open roles right now. Please check back soon.</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {careers.map((job: any) => (
              <article key={job._id} className="border rounded-lg p-5 hover:shadow-md transition-shadow">
                <div className="flex items-center justify-between gap-4">
                  <h2 className="text-xl font-semibold text-pretty">{job.title}</h2>
                  <span className="px-2.5 py-1 text-xs rounded-full bg-orange-100 text-orange-700 capitalize">
                    {job.type.replace("-", " ")}
                  </span>
                </div>
                <div className="mt-2 text-sm text-gray-600">
                  <span>{job.location}</span>
                  <span className="mx-2">•</span>
                  <span>{job.isRemote ? "Remote" : "On-site"}</span>
                </div>

                {job.salaryMin || job.salaryMax ? (
                  <div className="mt-2 text-sm text-gray-700">
                    Salary: {job.salaryCurrency || "INR"} {job.salaryMin ? job.salaryMin : ""}{" "}
                    {job.salaryMin && job.salaryMax ? "-" : ""} {job.salaryMax ? job.salaryMax : ""}
                  </div>
                ) : null}

                <p className="mt-3 text-gray-700 line-clamp-4">{job.description}</p>

                {Array.isArray(job.requirements) && job.requirements.length > 0 && (
                  <ul className="mt-4 list-disc pl-5 text-sm text-gray-700 space-y-1">
                    {job.requirements.slice(0, 4).map((req: string, idx: number) => (
                      <li key={idx}>{req}</li>
                    ))}
                  </ul>
                )}

                <div className="mt-5 flex flex-wrap items-center gap-3">
                  {job.applyUrl ? (
                    <Link
                      href={job.applyUrl}
                      className="inline-flex items-center px-4 py-2 rounded-md bg-black text-white hover:bg-gray-900 text-sm"
                    >
                      Apply
                    </Link>
                  ) : null}
                  {job.applyEmail ? (
                    <a
                      href={`mailto:${job.applyEmail}`}
                      className="inline-flex items-center px-4 py-2 rounded-md border text-sm"
                    >
                      Email HR
                    </a>
                  ) : null}
                </div>
              </article>
            ))}
          </div>
        )}
      </section>
    </main>
  )
}
