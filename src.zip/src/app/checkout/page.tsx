import CheckoutPage from "@/components/Checkout/pages/checkout"

export default function Checkout() {
  return (
    <div className="container mx-auto px-4 py-8">
      <CheckoutPage />
    </div>
  )
}
