import CategoryGrid from "@/components/categories/category-grid"

export default function CategoriesPage() {
  return (
    <div className="min-h-screen">
      <CategoryGrid />
    </div>
  )
}
