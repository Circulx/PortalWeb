import { Dashboard } from "@/components/admin/dashboard/dashboard"

export default function Home() {
  return <Dashboard />
}
