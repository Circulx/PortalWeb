import { SellerList } from "@/components/admin/sellers/seller-list"

export default function SellersPage() {
  return (
    <div className="container py-6">
      <SellerList />
    </div>
  )
}
