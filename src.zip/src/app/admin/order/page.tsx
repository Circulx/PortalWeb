import Dashboard from "@/components/admin/order/Dashboard"

export default function DashboardPage() {
  return <Dashboard />
}
