import { NextResponse } from "next/server"
import { connectProfileDB } from "@/lib/profileDb"

export async function GET() {
  try {
    const conn = await connectProfileDB()
    const Career = conn.models.Career
    const items = await Career.find({ isActive: true }).sort({ createdAt: -1 }).lean()
    return NextResponse.json({ success: true, data: items })
  } catch (err) {
    console.error("Public careers GET error:", err)
    return NextResponse.json({ success: false, error: "Failed to fetch careers" }, { status: 500 })
  }
}
