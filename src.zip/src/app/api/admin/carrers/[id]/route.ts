import { type NextRequest, NextResponse } from "next/server"
import { connectProfileDB } from "@/lib/profileDb"
import { getCurrentUser } from "@/actions/auth"

export async function PUT(_req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const user = await getCurrentUser()
    if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    if (user.type !== "admin") return NextResponse.json({ error: "Admin access required" }, { status: 403 })

    const payload = await _req.json()
    const conn = await connectProfileDB()
    const Career = conn.models.Career

    const updated = await Career.findByIdAndUpdate(
      params.id,
      {
        $set: {
          title: payload.title,
          type: payload.type,
          location: payload.location,
          isRemote: !!payload.isRemote,
          description: payload.description,
          responsibilities: payload.responsibilities || [],
          requirements: payload.requirements || [],
          salaryMin: payload.salaryMin ?? undefined,
          salaryMax: payload.salaryMax ?? undefined,
          salaryCurrency: payload.salaryCurrency || "INR",
          applyUrl: payload.applyUrl || "",
          applyEmail: payload.applyEmail || "",
          isActive: payload.isActive !== undefined ? !!payload.isActive : true,
          applicationDeadline: payload.applicationDeadline ? new Date(payload.applicationDeadline) : undefined,
          updatedAt: new Date(),
        },
      },
      { new: true, runValidators: true },
    )

    if (!updated) return NextResponse.json({ success: false, error: "Career not found" }, { status: 404 })
    return NextResponse.json({ success: true, data: updated, message: "Career updated" })
  } catch (err) {
    console.error("Careers PUT error:", err)
    return NextResponse.json({ success: false, error: "Failed to update career" }, { status: 500 })
  }
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const user = await getCurrentUser()
    if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    if (user.type !== "admin") return NextResponse.json({ error: "Admin access required" }, { status: 403 })

    const conn = await connectProfileDB()
    const Career = conn.models.Career

    const deleted = await Career.findByIdAndDelete(params.id)
    if (!deleted) return NextResponse.json({ success: false, error: "Career not found" }, { status: 404 })
    return NextResponse.json({ success: true, message: "Career deleted" })
  } catch (err) {
    console.error("Careers DELETE error:", err)
    return NextResponse.json({ success: false, error: "Failed to delete career" }, { status: 500 })
  }
}
