import { type NextRequest, NextResponse } from "next/server"
import { connectProfileDB } from "@/lib/profileDb"
import { getCurrentUser } from "@/actions/auth"

export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser()
    if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    if (user.type !== "admin") return NextResponse.json({ error: "Admin access required" }, { status: 403 })

    const conn = await connectProfileDB()
    const Career = conn.models.Career

    const { searchParams } = new URL(request.url)
    const page = Number.parseInt(searchParams.get("page") || "1")
    const limit = Number.parseInt(searchParams.get("limit") || "10")
    const isActive = searchParams.get("isActive")
    const type = searchParams.get("type")

    const filter: any = {}
    if (isActive === "true") filter.isActive = true
    if (isActive === "false") filter.isActive = false
    if (type && ["full-time", "part-time", "internship", "contract"].includes(type)) filter.type = type

    const total = await Career.countDocuments(filter)
    const items = await Career.find(filter)
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(limit)
      .lean()

    return NextResponse.json({
      success: true,
      data: { items, pagination: { page, limit, total, pages: Math.ceil(total / limit) } },
    })
  } catch (err) {
    console.error("Careers GET error:", err)
    return NextResponse.json({ success: false, error: "Failed to fetch careers" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser()
    if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    if (user.type !== "admin") return NextResponse.json({ error: "Admin access required" }, { status: 403 })

    const payload = await request.json()
    const conn = await connectProfileDB()
    const Career = conn.models.Career

    const doc = await Career.create({
      title: payload.title,
      type: payload.type,
      location: payload.location,
      isRemote: !!payload.isRemote,
      description: payload.description,
      responsibilities: payload.responsibilities || [],
      requirements: payload.requirements || [],
      salaryMin: payload.salaryMin ?? undefined,
      salaryMax: payload.salaryMax ?? undefined,
      salaryCurrency: payload.salaryCurrency || "INR",
      applyUrl: payload.applyUrl || "",
      applyEmail: payload.applyEmail || "",
      isActive: payload.isActive !== undefined ? !!payload.isActive : true,
      applicationDeadline: payload.applicationDeadline ? new Date(payload.applicationDeadline) : undefined,
    })

    return NextResponse.json({ success: true, data: doc, message: "Career created" })
  } catch (err) {
    console.error("Careers POST error:", err)
    return NextResponse.json({ success: false, error: "Failed to create career" }, { status: 500 })
  }
}
