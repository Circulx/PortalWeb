import ProductsPage from "@/components/products/Products"

export default function Products() {
  return (
    <div className="text-center p-4 md:p-6">
      <ProductsPage />
    </div>
  )
}

