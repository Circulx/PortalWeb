import CartPage from "@/components/dashboard/CartPage"

export default function DashboardCartPage() {
  return <CartPage />
}

