import CheckoutPage from "@/components/Checkout/pages/Checkout"

export default function Checkout() {
  return (
    <div className="text-center p-4 md:p-6">
      <CheckoutPage />
    </div>
  )
}
