import Cart from "@/components/cart/Cart"

export default function CartPage() {
  return (
    <div className="text-center p-4 md:p-6">
      <Cart />
    </div>
  )
}
